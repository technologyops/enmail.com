	var first = 1;
   	var last = 4;
        var current = 1;
           
        function nextPicture() {
               
               object = document.getElementById('slide' + current);
               object.style.display = 'none';
               
               if (current == last) { current = 1; }
               else { current++ }
               object = document.getElementById('slide' + current);
               object.style.display = 'block';
           }

         function previousPicture() {
                
               object = document.getElementById('slide' + current);
               object.style.display = 'none';
               
               if (current == first) { current = last; }
               else { current--; }
               object = document.getElementById('slide' + current);
               object.style.display = 'block';
           }