	

function keys(e)
{
var keynum;
 
if(window.event)  
	{

		key = event;
		keynum = key.keyCode;

	//keynum = e.keyCode;
	}
else if(e.which)  
	{
	keynum = e.which;
	}
switch (keynum) {
	case 32: 
	case 34:
 	case 39: 
	case 40:
		nextPicture();
		break;
	case 33:  
	case 37:  
	case 38:  
		previousPicture();
		break;
	}
}

function startup() {
	document.onkeyup = keys;
}

window.onload = startup;
