
Hi! The only relevant files are:

- Those in /css/milkbox/
- Those in /js/

The others are only there for demo purposes.
You can use milkbox.yui.js instead of milkbox.js

